drop table [dbo].[Incluido_em];
drop table [dbo].[Trans_de_Venda];
drop table [dbo].[Loja];
drop table [dbo].[Produto];
drop table [dbo].[Fornecedor];
drop table [dbo].[Regiao];
drop table [dbo].[Categoria];
drop table [dbo].[Cliente];